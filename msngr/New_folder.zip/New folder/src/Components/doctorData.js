{/* <ul className='cards__items'>
<CardItem
  src='/images/alam.PNG'
  tag='MBBS, MD (Neurology), BSMMU Fellowship in Neuro-electrophysiology (UM,Malaysia)'
  name="Associate Prof. Dr. Sk. Mahbub Alam"
  speciality='Consultant, Neuromedicine. Neurologist, Epileptologist & Neuromuscular Disorder Specialist'
  path='/chat/alam'
/>
<CardItem
  src='/images/khairul.PNG'
  name="Prof. Dr. Md. Kabirul Islam"
  tag='MBBS, MS (Ped. Surgery), FICS (USA), FRCS(Glasg). Trained in Pediatric Urology (UK) & Pediatric Laparoscopic Surgery (India).'
  speciality='Senior Consultant, Pediatric Surgery'
  path='/chat/khairul'
/>
<CardItem
  src='/images/asif.PNG'
  tag=' MBBS, D. Card (London), Msc Cardiology (UK), Fellow, Pediatric Cardiology & Fetal Echocardiography (India)'
  name="Dr. Asif Manwar"
  speciality='Associate Consultant, Cardiology'
  path='/chat/asif'
/>
</ul>
<ul className='cards__items'>
<CardItem
  src='/images/mansur.PNG'
  tag='MBBS, MD (Cardiology), Fellow, Interventional Cardiology Fellow, Pacing, EP and Device Implantation'
  name="Dr. Mahbub Mansur"
  speciality='Senior Consultant, Interventional Cardiology'
  path='/chat/mansur'
/>
<CardItem
  src='/images/tahura.PNG'
  tag='MBBS, FCPS (Paediatrics), Fellowship in Paediatric Interventional Pulmonology'
  name="Dr. Sarabon Tahura"
  speciality='Associate Consultant of Paediatric Respiratory Medicine (Part time)'
  path='/chat/tahura'
/>
<CardItem
  src='/images/farzana.PNG'
  tag='FCPS (Medicine), MRCP (UK), MD (Rheumatology)'
  name="Dr. Farzana Shumy"
  speciality='Associate Consultant- Rheumatology and Internal Medicine'
  path='/chat/farzana'
/>
</ul> */}