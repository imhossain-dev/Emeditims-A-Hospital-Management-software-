import React, { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import './Navbar.css';

function Navbar() {
  const [click, setClick] = useState(false);
  const [button, setButton] = useState(true);
  const handleClick = () => setClick(!click);
  const closeMobileMenu = () => setClick(false);
  const [loggedIn, setLoggedIn]= useState(false)

  const showButton = () => {
    if (window.innerWidth <= 960) {
      setButton(false);
    } else {
      setButton(true);
    }
  };

  const SignOut = () =>{
    localStorage.removeItem("LoggedIn")
    setLoggedIn(false)
    console.log("removed Item")
  }

  useEffect(() => {
    showButton();
    setLoggedIn(localStorage.getItem("LoggedIn"))
  }, [loggedIn]);

  window.addEventListener('resize', showButton);
  

  return (
    <>
      <nav className='navbar'>
        <div className='navbar-container'>
          <Link to='/' className='navbar-logo' onClick={closeMobileMenu}>
            Doctor<b style={{color: "red"}}>Boost</b>
            <i class='fab fa-typo3' />
          </Link>
          <div className='menu-icon' onClick={handleClick}>
            <i className={click ? 'fas fa-times' : 'fas fa-bars'} />
          </div>
          <ul className={click ? 'nav-menu active' : 'nav-menu'}>
            <li className='nav-item'>
              <Link to='/' className='nav-links' onClick={closeMobileMenu}>
                Home
              </Link>
            </li>

            {loggedIn?
            <li className='nav-item'>
            <Link
              to='/'
              className='nav-links'
              onClick={SignOut}
            >
              SIGN OUT
            </Link>
          </li>:
              <li className='nav-item'>
              <Link
                to='/sign-up'
                className='nav-links'
                onClick={closeMobileMenu}
              >
                SIGN UP
              </Link>
            </li>
            }

            
            {
              loggedIn?
              ""
              :
              <li className='nav-item'>
              <Link
                to='/sign-in'
                className='nav-links'
                onClick={closeMobileMenu}
              >
                SIGN IN
              </Link>
            </li>
            }

          </ul>
        </div>
      </nav>
    </>
  );
}

export default Navbar;